function [lheat,qv,qc,qr,rainnc,rainncv] = kessler(t,pres,snew,qv,qc,...
                         qr,exn,z,rainnc,rainncv)
% ***********************************************
% Kessler (1969) microphysics scheme
% adapted by from WRF V2.1, Wolfgang Langhans 2010
% vectorisation, minor bugfixes, Lukas Papritz (2012)
% ***********************************************

% global variables
% ------------------------------------------
global nz nxb dt dth vt_mult autoconv_th autoconv_mult iern ...
       r r_v sediment_on cp

dt_in = 2*dt;		% saturation adjustment for leapfrog (2 * dt)

% define constants
c1 = 0.001 * autoconv_mult;
c2 = autoconv_th; % originally 0.001
c3 = 2.2;
c4 = 0.875;
%svp1 = 0.6112;
svp2 = 17.67;
svp3 = 29.65;
svpt0 = 273.15;
ep2 = r/r_v;
xlv = 2.5E06;
max_cr_sedimentation = 0.75;
rhowater = 1000.;

% transpose input fields
rainnc_tr = rainnc';
rainncv_tr = rainncv';
t_tr = t';

% reset rain rate to zero
rainncv_tr(:)=0.;

% compute density
% ------------------------
k=1:nz;
rho(:,k) = snew(:,k).*dth./(z(:,k+1)-z(:,k));

f5 = svp2*(svpt0 - svp3)*xlv/cp;

i=1:nxb;
k=1:nz;

% terminal velocity calculation and advection
% ------------------------
% setup coefficients and compute stable timestep
prod = qr;
qrr = max(zeros(nxb,nz),0.001 * qr .* rho);  % 10^(-3) * density of rain
vtden = sqrt(repmat(rho(:,1),1,nz)./rho);
vt_fact = vt_mult * 36.34 * vtden;
vt = (qrr.^0.1364).*vt_fact;

% 1/dz
rdzw = 1./(z(i,k+1)-z(i,k));

% determine courant number
crmax = max(dt_in / 2 * vt .* rdzw,zeros(nxb,nz));

% determine maximum nfall for all grid points
nfall = max(max(max(ones(nxb,nz),ceil(0.5+crmax/max_cr_sedimentation))));

% splitting so Courant number for sedimentation is stable
dtfall = dt_in/nfall;
time_sediment = dt_in;

%Terminal velocity calculation and advection
% Do a time split loop on this for stability
if (sediment_on==1)  
    rdzwdrho = rdzw./rho;
    while (nfall > 0) 

        time_sediment = time_sediment - dtfall;
        factor = dtfall*rdzwdrho;

        ppt = rho(:,1).*prod(:,1).*vt(:,1)*dtfall/rhowater;
        
        rainncv_tr =  ppt.*1000 ./dtfall *3600;  % precip (mm/h)
        rainnc_tr = rainnc_tr + ppt*1000;   %accumulated precip (mm)

        %Time split loop, fallout with flux upstream
        zw = prod.*vt.*rho;
        
        %the zw matrix is very sparse, only calculate the nonzero elements
        k_max = find(max(zw,[],1),1,'last'); 
        
        if (k_max == nz)
            k=1:nz-1;
            prod(:,k)  = prod(:,k) - factor(:,k).*(zw(:,k)- zw(:,k+1));
            prod(:,nz) = prod(:,nz) - factor(:,nz).*zw(:,nz)./rho(:,nz);
        else
            k = 1:k_max;
            prod(:,k)  = prod(:,k) - factor(:,k).*(zw(:,k)- zw(:,k+1));
        end
        
        %compute new sedimentation velocity, and check/recompute new 
        % sedimentation timestep if this isnt the last split step
        if (nfall > 1) %this wasnt the last split sedminentation timestep
          nfall = nfall - 1;
          crmax=0;
          qrr = max(zeros(nxb,nz),0.001 .* prod .* rho);
          vt = (qrr.^0.1364).*vt_fact;
          
          crmax = max(crmax * ones(nxb,nz), time_sediment * vt .* rdzw);
          nfall_new = max(max(max(ones(nxb,nz),ceil(0.5+crmax/max_cr_sedimentation))));

          if (nfall_new ~= nfall)
            nfall = nfall_new;
            dtfall = time_sediment/nfall;
          end %if
          
        else % this was the last timestep (nfall==1)

          prodqc = prod;
          nfall = 0;

        end %if
    end % of sedimentation while-loop

else %if (sediment_on==0)
      prodqc = zeros(nxb,nz);
end % if sediment_on


%Production of rain and deletion of qc
%Production of qc from supersaturation
%Evaporation of rain
k=1:nz;
factorn = ones(nxb,nz) ./ (1+c3*dt_in*max(zeros(nxb,nz),qr).^c4);

%autoconversion and accretion
qrprod = qc .* (1-factorn) + c1*dt_in*factorn.*max(zeros(nxb,nz),qc-c2);

rcgs = 0.001*rho;

%set limit
qc = max(qc-qrprod,zeros(nxb,nz));

qr = qr + prodqc - qr;

%set limit
qr = max(qr(i,k)+qrprod,zeros(nxb,nz));

%atmospheric conditions
pii = exn/cp;
temp = 0.5*(pii(i,k+1).*repmat(t_tr(k+1),nxb,1)+pii(i,k).*repmat(t_tr(k),nxb,1));
pressure = 0.5.*(pres(i,k)+pres(i,k+1));%1E05* (0.5*(pii(i,k+1)+pii(i,k))^(1004/287));
gam = 2.5E06./(1004*0.5*(pii(i,k)+pii(i,k+1))); % L / (cp_d * exn/cp)
%es = 1000*svp1*exp(svp2*(temp-svpt0)/(temp-svp3))
es = eswat1(temp)*100;
qvs = ep2.*es./(pressure-es);

%calculate saturation deficit
diff = qvs-qv;
diff(diff<0)=0;

%saturation adjustment: condensation/evaporation 
produc = (qv-qvs)./ ...
(1+pressure./(pressure-es).*qvs.*f5./(temp-svp3).^2);

%evaporation of rain
if (iern == 1)
    ern = min(dt_in*(((1.6+124.9*(rcgs.*qr).^0.2046)...
    .*(rcgs.*qr).^0.525)./(2.55E8./(pressure.*qvs)...
    +5.4E5)).*(diff./(rcgs.*qvs)),max(-produc-qc,zeros(nxb,nz)));
    %limit evaporation of rain to current rain amount
    ern = min(ern,qr);
else
    ern = 0.;
end % if

%finally update all variables (except temperature)
production = max(produc,-qc);
lheat = gam.*(production-ern);
qv = max(qv-production+ern,zeros(nxb,nz));
qc = qc + production;
qr = qr - ern;

rainnc = rainnc_tr';
rainncv = rainncv_tr';

%qr(i,k) = qr(i,k) + qc(i,k) ;
%qc(i,k) = 0;
