% -------------------------------------------------------------------
% Produces Hovmoeller plots (x,t-plots) of velocity 
%
% Input:
%   simname	    Simulation name
%   zlev	    level number
%
% Example:
%   hovx_vel('default', 1)
%
% -------------------------------------------------------------------
function hovx_vel(simname, zlev, device)

% read simulation data
v = readsim(simname);
s = size(v.u);
dat = reshape(v.u(:,zlev,:), s([1,3]));

% produce the figure
figure('Name', simname);
[c,h] = contour(v.x(:,1), v.t/3600, dat', 0:1:40, 'r');
clabel(c,h,'LabelSpacing',300);
title(strcat(['Velocity at zlev = ' num2str(zlev)]))
xlabel('x [km]')
ylabel('Time [h]')

% print the figure into a file
if nargin > 2
    fig_fn = strcat('fig/', simname, '_hovx');
    print(gcf, device, fig_fn);
end %if

