function solver()
clear all;

%     ***************************************************************
%     * 2-dimensional isentropic model                              *
%     * Christoph Schaer, Spring 2000                               *
%     * Several extensions, Juerg Schmidli, 2005                    *
%     * Converted to matlab, David Masson, 2009                     *
%     * Subfunction structure, bugfixes, and Kessler scheme added   *
%     * Wolfgang Langhans, 2009/2010                                *
%     * 2 moment scheme, bug fixes, vectorizations, addition of     *
%     * improvements by Mathias Hauser, Deniz Ural,                 *
%     * Lukas Papritz, 2012 / 2013                                  *
%     ***************************************************************

% -----------------------------------------------------------
% -------------------- MAIN PROGRAM: SOLVER -----------------
% -----------------------------------------------------------

% define global variables
% ----------------------
global g cp r topotim nab diffabs irelax idbg iprtcfl imoist itime ...
       imicrophys imoist_diff idthdt iout nx nx1 nxb nxb1 nz nz1 ...
       dx thl nb dt dtdx time  ...
       iiniout diff dth Z U S T QV QC QR NC NR TOT_PREC PREC LHEAT

% read input namelist 
% ----------------------
namelist();

% compute input parameters
% ----------------------
dth     = thl/nz;           % spacing between vertical layers [K]
nts     = round(time/dt);   % number of iterations
nout    = nts/iout;         % number of output steps

nx1     = nx+1;             % number of staggered gridpoints in z
nz1     = nz+1;             % number of staggered gridpoints in z
nxb     = nx+2*nb;          % x range of unstaggered variable
nxb1    = nx1+2*nb;         % x range of staggered variable

% increase numer of output steps by 1 for initial profile
% ----------------------
if (iiniout == 1)
   nout = nout + 1;
end %if

% Define physical fields
% ----------------------

% topography
topo(1:nxb,1) = 0;

% height in z-coordinates
zhtold(1:nxb,1:nz1) = 0;  	
zhtnow = zhtold;
Z(1:nx,1:nz1,nout) = 0 ;% auxiliary field for output

% horizontal velocity
uold(1:nxb1,1:nz) = 0;
unow = uold;
unew = uold;
U(1:nx,1:nz,nout) = 0; 	%  auxiliary field for output

% isentropic density
sold(1:nxb,1:nz) = 0;
snow = sold;
snew = sold;
S(1:nx,1:nz,nout) = 0; 	% auxiliary field for output

% montgomery potential
mtg(1:nxb, 1:nz) = 0;
mtgnew = mtg;
mtg0 = mtg(1,:);

% exner function
exn(1:nxb, 1:nz1) = 0;
exn0(1:nz1) = 0;

% pressure
prs(1:nxb, 1:nz1) = 0;
prs0(1:nz1) = 0;

% output time vector
T = (1:nout);   	

if (imoist==1)
    % precipitation
    prec(1:nxb) = 0;
    PREC(1:nx,nout) = 0; %  auxiliary field for output
   
    % accumulated precipitation
    tot_prec(1:nxb) = 0;
    TOT_PREC(1:nx,nout) = 0; %  auxiliary field for output
    
    % latent heating
    dthetadt(1:nxb,1:nz1) = 0;
    LHEAT(1:nx,1:nz,nout) = 0; % auxiliary field for output (K/s)
    
    % specific humidity
    qvold(1:nxb,1:nz) = 0;
    qvnow = qvold;
    qvnew = qvold;
    QV(1:nx,1:nz,nout) = 0; % auxiliary field for output
    
    % specific cloud water content
    qcold(1:nxb,1:nz) = 0;
    qcnow = qcold;
    qcnew = qcold;
    QC(1:nx,1:nz,nout) = 0; % auxiliary field for output
    
    % specific rain water content
    qrold(1:nxb,1:nz) = 0;
    qrnow = qrold;
    qrnew = qrold;
    QR(1:nx,1:nz,nout) = 0; % auxiliary field for output
    
    % rain-droplet number density
    nrold(1:nxb,1:nz) = 0;
    nrnow = nrold;
    nrnew = nrold;
    NR(1:nx,1:nz,nout) = 0; % auxiliary field for output
    
    % cloud droplet number density
    ncold(1:nxb,1:nz) = 0;
    ncnow = ncold;
    ncnew = ncold;
    NC(1:nx,1:nz,nout) = 0; % auxiliary field for output
end %if

% Define fields at lateral boundaries
% 1 denotes the leftern boundary
% 2 denotes the rightern boundary
% ----------------------

% topography
tbnd1 = 0.;
tbnd2 = 0.;

% isentropic density
sbnd1(1:nz) = 0.;
sbnd2(1:nz) = 0.;

% horizontal velocity
ubnd1(1:nz) = 0.;
ubnd2(1:nz) = 0.;

% specific humidity
qvbnd1(1:nz) = 0;
qvbnd2(1:nz) = 0;

% specific cloud water content
qcbnd1(1:nz) = 0;
qcbnd2(1:nz) = 0;

% specific rain water content
qrbnd1(1:nz) = 0;
qrbnd2(1:nz) = 0;

% latent heating
dthetadtbnd1(1:nz1) = 0;
dthetadtbnd2(1:nz1) = 0;

% rain droplet number density
nrbnd1(1:nz) = 0;
nrbnd2(1:nz) = 0;

% cloud droplet number density
ncbnd1(1:nz) = 0;
ncbnd2(1:nz) = 0;

% Set initial conditions
% ----------------------
if (idbg==1)
  fprintf('Setting initial conditions ...\n');
end


if (imoist==0)
   % dry atmosphere
  [th0,exn0,prs0,z0,mtg0,s0,u0,sold,snow,uold,unow,mtg,mtgnew] = ...
  makeprofile(sold,snow,uold,                                    ...
              unow,mtg,mtgnew);
else
  if (imicrophys==0 || imicrophys==1) 
      % moist atmosphere with kessler scheme
      [th0,exn0,prs0,z0,mtg0,s0,u0,sold,snow,uold,unow,mtg,          ...
      mtgnew,qv0,qc0,qr0,qvold,qvnow,qcold,qcnow,qrold,qrnow]      = ...
      makeprofile(sold,snow,uold,                                    ...
                  unow,mtg,mtgnew,qvold,qvnow,qcold,                 ...
                  qcnow,qrold,qrnow);
  elseif (imicrophys==2)
      % moist atmosphere with 2-moment scheme
      [th0,exn0,prs0,z0,mtg0,s0,u0,sold,snow,uold,unow,mtg,          ...
      mtgnew,qv0,qc0,qr0,qvold,qvnow,qcold,qcnow,qrold,qrnow,        ...
      ncold,ncnow,nrold,nrnow]      =                                ...
      makeprofile(sold,snow,uold,                                    ...
                  unow,mtg,mtgnew,qvold,qvnow,qcold,                 ...
                  qcnow,qrold,qrnow,ncold,ncnow,nrold,nrnow);  
  end % if
end %if

% Save boundary values for the lateral boundary relaxation
if (irelax==1)
  if (idbg==1)
    fprintf('Saving initial lateral boundary values ...\n');
  end %if
  
  k=1:nz;
  sbnd1(k) = snow(1,k);
  sbnd2(k) = snow(nxb,k);
  
  ubnd1(k) = unow(1,k);
  ubnd2(k) = unow(nxb1,k);


  if (imoist==1)
    qvbnd1(k) = qvnow(1,k);
    qvbnd2(k) = qvnow(nxb,k);
    
    qcbnd1(k) = qcnow(1,k);
    qcbnd2(k) = qcnow(nxb,k);
    
    qrbnd1(k) = qrnow(1,k);
    qrbnd2(k) = qrnow(nxb,k);
    
    k=1:nz1;
    dthetadtbnd1(k) = dthetadt(1,k);
    dthetadtbnd2(k) = dthetadt(nxb,k);
    
    % 2-moment
    if (imicrophys==2)
        k=1:nz ;
        ncbnd1(k) = ncnow(1,k);
        ncbnd2(k) = ncnow(nxb,k);
        
        nrbnd1(k) = nrnow(1,k);
        nrbnd2(k) = nrnow(nxb,k);
    end % if
  end %if
end %if irelax

% make topography
% ----------------------
[topo]=maketopo(topo,nxb);

% switch between boundary relaxation / periodic boundary conditions
% -------------------------------
if (irelax == 1)          % boundary relaxation
   if (idbg==1)
     fprintf('Relax topography ...\n');
   end %if
   
  % save lateral boundary values of topography
  tbnd1 = topo(1);
  tbnd2 = topo(nxb);
  
  % relax topography
  topo = relax(topo,nx,nb,tbnd1,tbnd2);

else
    if (idbg==1)
      fprintf('Periodic topography ...\n');
    end %if
    
    % make topography periodic
    topo = periodic(topo,nx,2);         
end %if

% calculate geometric height (staggered)
i=1:nxb;
zhtnow(i,1) = 0.;
for k=2:nz1;
    zhtnow(i,k) = zhtnow(i,k-1) - (r/cp/g)...
               * 0.5*(th0(k-1).*exn0(k-1)+th0(k).*exn0(k))...
                .* (prs0(k)-prs0(k-1))...
                ./ (0.5*(prs0(k)+prs0(k-1)));
end %for

% Height-dependent diffusion coefficient 
% --------------------------------------
k=1:nz;
tau(k) = diff; 

% *** Exercise 3.1 height-dependent diffusion coefficient ***
% *** edit here ***
	for i=(nz-nab+1):nz;
    tau(i)=diff+(diffabs-diff)*(sin(pi*(i-nz+nab)/(2*nab)))^2;
    end ;
%
% *** Exercise 3.1 height-dependent diffusion coefficient ***

% output inital fields
% ----------------------
its_out = 0 ; % logfile index
if (iiniout == 1)
  if (imoist==1)
      [its_out] =               ...
      makeoutput(unow,snow,zhtnow,its_out,0,qvnow,qcnow,qrnow,ncnow,nrnow,dthetadt,tot_prec,prec);
  else
      [its_out] =               ...
      makeoutput(unow,snow,zhtnow,its_out,0);
  end %if
end %if

% ############### TIME LOOP #########################################    
% -------------------------------------------------------------------
% Loop over all time steps
% -------------------------------------------------------------------
if (idbg==1)
  fprintf('Starting time loop ...\n');
end %if

t0 = clock ;
for its=1:nts

    % calculate time
    time = its*dt;
    if (idbg==1 || idbg==0)
       fprintf('==================================================================\n');
       fprintf('Working on timestep %g; time = %g s\n',its,time);
       fprintf('==================================================================\n');
    end %if

    % initially increase height of topography only slowly
    topofact = min(1., time/topotim);

    % Special treatment of first time step
    % -------------------------------------
    if (its == 1)
        dtdx = dt/dx/2.;
        if (imoist==1)
           dthetadt(1:nxb,1:nz1) = 0; % No latent heating for first time-step
        end 
        if (idbg==1)
           fprintf('Using Euler forward step for 1. step ...\n');
        end %if
    else
        dtdx = dt/dx;
    end % if
   

    % *** Exercise 2.1 isentropic mass density ***
    % *** time step for isentropic mass density ***
    % *** edit here ***
 
    
    %
    % *** Exercise 2.1 isentropic mass density ***
    
    % *** Exercise 4.1 / 5.1 moisture ***
    % *** time step for moisture scalars ***
    if (imoist==1)
    % *** edit here ***
        
    end %if
                   
    %
    % *** Exercise 4.1 / 5.1 moisture scalars *** 


    % *** Exercise 2.1 velocity ***
    % *** time step for momentum ***
    % *** edit here ***

    [snew] = prog_isendens(sold,snow,unow);

    % *** Exercise 2.1 velocity ***
    [unew] = prog_velocity(uold,unow,mtg);
    
    % exchange boundaries if periodic
    % -------------------------------------
    if (irelax==0) 
        snew = periodic(snew,nx,nb);
        unew = periodic(unew,nx+1,nb);

        if (imoist==1)
           qvnew = periodic(qvnew,nx,nb);
           qcnew = periodic(qcnew,nx,nb);
           qrnew = periodic(qrnew,nx,nb);

           % 2-moment
           if (imicrophys==2)
               ncnew = periodic(ncnew,nx,nb);
               nrnew = periodic(nrnew,nx,nb);
           end % if
        end %if
    end %if
    % -------------------------------------
       
    % relaxation of prognostic fields
    % ---------------------------------
    if (irelax == 1)
       if (idbg==1)
          fprintf('Relaxing prognostic fields ...\n');
       end %if
                snew = relax(snew,nx,nb,sbnd1,sbnd2);
                unew = relax(unew,nx1,nb,ubnd1,ubnd2);
                
                if (imoist==1)
                    
                  qvnew = relax(qvnew,nx,nb,qvbnd1,qvbnd2);
                  qcnew = relax(qcnew,nx,nb,qcbnd1,qcbnd2);
                  qrnew = relax(qrnew,nx,nb,qrbnd1,qrbnd2);
                  
                  % 2-moment
                  if (imicrophys==2)
                       ncnew = relax(ncnew,nx,nb,ncbnd1,ncbnd2);
                       nrnew = relax(nrnew,nx,nb,nrbnd1,nrbnd2);
                  end %if
                end %if
    end %if
    
    if (idbg==1)
       fprintf('Preparing next time step ...\n');
    end %if

    % *** Exercise 2.1 / 4.1 / 5.1 ***
    % *** exchange isentropic mass density and velocity (later also qv,qc,qr,nc,nr)***
    % *** edit here ***
    %
    
    sold = snow;
    snow = snew;
    uold = unow;
    unow = unew;
   
    %
    % *** Exercise 2.1 / 4.1 / 5.1 ***
   
    
    % Diffusion and gravity wave absorber
    % ---------------------------------
    if (imoist==0)
      [unew,unow,snew,snow] = horizontal_diffusion(tau,unow,unew,snow,snew);   
    else
      if (imicrophys==2)
            [unew,unow,snew,snow,qvnew,qvnow,qcnew,qcnow,qrnew,qrnow,ncnew,ncnow,nrnew,nrnow] = ...
            horizontal_diffusion(tau,unow,unew,snow,snew,qvnow,qvnew,qcnow,qcnew,qrnow,qrnew,ncnow,ncnew,nrnow,nrnew);
      else
            [unew,unow,snew,snow,qvnew,qvnow,qcnew,qcnow,qrnew,qrnow] = ...
            horizontal_diffusion(tau,unow,unew,snow,snew,qvnow,qvnew,qcnow,qcnew,qrnow,qrnew);  
      end %if 
    end %if 
    

    % *** Exercise 2.2 (also 1.4) Diagnostic computation of pressure ***
    % *** Diagnostic computation of pressure ***
    % *** edit here ***
    %
    

    % *** Exercise 2.2 Diagnostic computation of pressure ***
    [prs] = diag_pressure(prs0,prs,snow);
    
    % *** Exercise 2.2 (also 1.5) Diagnostic computation of Montgomery ***
    % *** Calculate Exner function and Montgomery potential ***
    % *** edit here ***
    
    [exn,mtg] = diag_montgomery(prs,mtg,th0,topo,topofact);

    % *** Exercise 2.2 Diagnostic computation  ***


    % Calculation of geometric height (staggered)
    % needed for output and microphysics schemes
    % -------------------------------------------

    zhtold=zhtnow;
    
    i=1:nxb;
    zhtnow(i,1) = topo(i)*topofact;
    for k=2:nz+1;
        zhtnow(i,k) = zhtnow(i,k-1) - (r/cp/g)...
                   * 0.5*(th0(k-1).*exn(i,k-1)+th0(k).*exn(i,k))...
                   .* (prs(i,k)-prs(i,k-1))...
                   ./ (0.5*(prs(i,k)+prs(i,k-1)));
    end %for
   
    if (imoist==1)
        
      % *** Exercise 4.1 Moisture ***
      % *** Clipping of negative values ***
      % *** Edit here ***
                          
	
      % *** Exercise 4.1 Moisture ***
     
      if (imicrophys ==1)

                     % *** Exercise 4.2 Kessler ***
                     % *** Kessler scheme ***
                     % *** Edit here ***
         
                     % add call of kessler, which computed latent heat tmp,
                     % subfunction here: 

      
                    % *** Exercise 4.2 Kessler ***
      elseif (imicrophys==2)
              
                    % *** Exercise 5.1 Two Moment Scheme ***
                    % *** Two Moment Scheme ***
                    % *** Edit here ***
                    

                    
                    % *** Exercise 5.1 Two Moment Scheme ***

      end %if imicrophys
   
      
      if (imicrophys > 0)
        if (idthdt==1)     %diabatic flow
          for k=2:nz ;     %stagger heating tmp to model levels and compute tendency
                           % get tendency by division of 2dt -> leapfrog
              dthetadt(1:nxb,k) = topofact*0.5.*(tmp(1:nxb,k-1)+tmp(1:nxb,k))./(2.*dt);

          end %for
          clear('tmp');
          dthetadt(1:nxb,1)   = 0.; %force dthetadt to zero at bottom
          dthetadt(1:nxb,nz1) = 0.; %and at the top

          % periodic lateral boundary conditions
          % ----------------------------
          if (irelax==0)
            dthetadt = periodic(dthetadt,nx,nb);
          else
        
          % Relax latent heat fields
          % ----------------------------
             [dthetadt] = relax(dthetadt,nx,nb,dthetadtbnd1,dthetadtbnd2);
          end %if
        else               % adiabatic flow
          dthetadt(1:nxb,1:nz1) = 0.;
        end
      end %if imicrophys


      % prepare next time step
      % ----------------------------
      qvnow = qvnew;
      qcnow = qcnew;
      qrnow = qrnew;
      
      if (imicrophys==2)
          ncnow = ncnew;
          nrnow = nrnew;
      end %if
    end %if imoist

 
    % check maximum cfl criterion   
    % -------------------------------------------
    if (iprtcfl==1)
       u_max = max(max(abs(unew)));
       cfl_max = u_max*dtdx;
       fprintf('==================================================================\n');
       fprintf('CFL MAX: %g U MAX: %g m/s \n', cfl_max, u_max);
       if (cfl_max > 1) 
          fprintf('!!! WARNING: CFL larger than 1 !!!\n');
       elseif (isnan(cfl_max) == 1)
          fprintf('!!!  MODEL ABORT: NaN values   !!!\n');
         % exit;
       end %if
       fprintf('==================================================================\n');
    end %if  
  
    
    % output every 'iout'-th time step
    % -------------------------------------------
    if (mod(its,iout)==0)
       if (imoist==1)
         [its_out] =               ...
         makeoutput(unow,snow,zhtnow,its_out,its,qvnow,qcnow,qrnow,ncnow,nrnow,dthetadt,tot_prec,prec);
       else
         [its_out] =               ...
         makeoutput(unow,snow,zhtnow,its_out,its);
       end %if
    end %if       

    if (idbg==1)
        fprintf(' \n');
        fprintf(' \n');
    end %if

end % "for loop" for time steps
% -------------------------------------------------------------------
% ############### END OF TIME LOOP ################################## 
if (idbg==1)
   fprintf(' \n');
   fprintf('End of time loop ...\n');
end %if

% Write logfile
% ----------------------------
write_logfile(nout);

t1 = clock ;

if (itime==1)
   fprintf('Total elapsed computation time: %g s\n', etime(t1, t0));
end %if

%end of function
