function [qvnew,qcnew,qrnew] = prog_moisture(unow,qvold,qcold,qrold,...
                              qvnow,qcnow,qrnow,qvnew,qcnew,qrnew,dthetadt)

% global variables
% ----------------------
global nz idbg nb nx dt dtdx idthdt dth  

    if (idbg==1)
       fprintf('Prognostic step: Moisture scalars ...\n');
    end %if

    % declare
    qvnew = zeros(nx+2*nb,nz);
    qcnew = zeros(nx+2*nb,nz);
    qrnew = zeros(nx+2*nb,nz);


    % *** Exercise 4.1 moisture advection ***
    % *** edit here *** 
    %
   
    %
    % *** Exercise 4.1  ***

