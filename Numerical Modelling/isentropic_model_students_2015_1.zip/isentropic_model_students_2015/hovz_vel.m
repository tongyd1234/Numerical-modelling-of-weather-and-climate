% -------------------------------------------------------------------
% Produces Hovmoeller plots (t,z-plots) of velocity 
%
% Input:
%   simname	    Simulation name
%   xc		    x coordinate in grid points
%
% Optional Input:
%   '-deps2'	    output device
%
% Example:
%   hovz_vel('h1400_long', 55)
%   hovz_vel('h1000_nosponge', 55, '-deps2c')
%
% -------------------------------------------------------------------
function hovz_vel(simname, xc, device)

% read the simulation data
v = readsim(simname);
s = size(v.u);
dat = reshape(v.u(xc,:,:), s([2,3]));
zc = squeeze(v.z(xc,:,1));

% produce the figure
figure('Name', simname);
[c,h] = contour(v.t/3600, zc, dat, 0:1:40, 'r');
clabel(c,h,'LabelSpacing',300);
title(strcat(['Velocity at x = ' num2str(xc)]))
xlabel('Time [h]')
ylabel('Height [km]')

% print the figure into a file
if nargin > 2
    fig_fn = strcat('fig/', simname, '_hovz');
    print(gcf, device, fig_fn);
end %if
