function [mixv1] = rrmixv1(p,T,humv,kindhum)
%
% computes mixing ratio in (g/g)
%
% INPUT: p     ... pressure in [hPa]
%        T     ... temperature [K]
%        humv  ... humidity variable; one of: dew point [K]
%                                             relative humidity [0-1]
%        kindhum . kind of humidity variable: 1 = dew point [K]
%                                             2 = relative humidity [0-1]
%
      eps= 0.62198;
      cpd = 1004.7;

      if kindhum==1         % dew point is the input
        esat = eswat1(humv);
        mixv1 = eps*esat ./ (p - esat);
      elseif kindhum==2     % relative humidity is the input
        esat  = eswat1(T);

        len= size(p);
        mixv1(1:len(1),1:len(2)) = NaN; %predefine mixing ratio

        ind1 = find(esat >= 0.616*p);
        if ~isempty(ind1)
          mixv1(ind1)=0;
        end

        ind2 = find(esat < 0.616*p);
        if ~isempty(ind2)
          mixv1(ind2) = eps*humv(ind2).*esat(ind2) ./ ...
                  (p(ind2) - humv(ind2).*esat(ind2) );
        end
      end
