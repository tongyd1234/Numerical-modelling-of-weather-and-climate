function [ncnew,nrnew] = prog_numdens(unow,ncold,nrold,...
                              ncnow,nrnow,ncnew,nrnew,dthetadt)

% global variables
% ----------------------
global nz idbg nb nx dt dx idthdt dth  

% local variables
% ----------------------
dtdx = dt/dx;

    if (idbg==1)
       fprintf('Prognostic step: Number densities ...');
    end %if

    % declare
    ncnew = zeros(nx+2*nb,nz);
    nrnew = zeros(nx+2*nb,nz);

    % *** Exercise 5.1/5.2 Two Moment Scheme ***
    % *** edit here *** 
    %
   
    %
    % *** Exercise 5.1/5.2  ***

    
