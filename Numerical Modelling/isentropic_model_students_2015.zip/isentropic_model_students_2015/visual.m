% -------------------------------------------------------------------
% Used for the animation of the isentrop model output.
% This function is called by anim.m.
%
% Juerg Schmidli, 2005
%
% Deniz Ural, 2012
%   - goto_first, goto_last buttons
%   - slider 
%   - additional variables
%
% Lukas Papritz, 2013
%   - simultaneous plotting of several fields
% -------------------------------------------------------------------
%
function visual(varargin)

global VisData slider_Hnd slider_text FigVisual %

switch nargin
    case 0
        error('ERROR: No Data to visualize');
        
    case 1
        % Handle UIControls
        Action = varargin{1};
        if ~isstr(Action)
            error('Invalid Action for linadv');
        end % if
        
        [hnd, Fig] = gcbo;
        Data = get(Fig, 'UserData');
                
        switch Action        
            case 'close'
                close(gcf);
                
            % Callback functions    
                
            case 'slider'
                Vis = get(gca, 'UserData');
                Vis.play = 0;
                Vis.n = round(get(slider_Hnd, 'Value'));
                Vis.step = 0;                
                set(gca, 'UserData', Vis);                
                LocalShow(VisData); 
                            
            case 'goto_first'
                Vis = get(gca, 'UserData');
                Vis.play = 0;
                Vis.n = 1;                
                Vis.step = 0; 
                set(slider_Hnd, 'Value', 1);
                set(gca, 'UserData', Vis);
                LocalShow(VisData);              
                
            case 'bw_play'
                Vis = get(gca, 'UserData');
                Vis.play = 1;
                Vis.step = -1;
                set(gca, 'UserData', Vis);
                LocalShow(VisData);
                
            case 'bw_step'
                Vis = get(gca, 'UserData');
                Vis.play = 0;
                Vis.step = -1;
                set(gca, 'UserData', Vis);
                LocalShow(VisData);
                
            case 'stop'
                Vis = get(gca, 'UserData');
                Vis.play = 0;
                Vis.step = 0;
                set(gca, 'UserData', Vis);
                LocalShow(VisData);
                
            case 'fw_step'
                Vis = get(gca, 'UserData');
                Vis.play = 0;
                Vis.step = 1;
                set(gca, 'UserData', Vis);
                LocalShow(VisData);
                
            case 'fw_play'
                Vis = get(gca, 'UserData');
                Vis.play = 1;
                Vis.step = 1;
                set(gca, 'UserData', Vis);
                LocalShow(VisData);
                
            case 'goto_last'  
                Vis = get(gca, 'UserData');
                Vis.play = 0;
                Data   = get(gcf, 'UserData');
                time   = Data.Vis.t;
                Vis.n = length(time);
                Vis.step = 0;
                set(slider_Hnd, 'Value', Vis.n);
                set(gca, 'UserData', Vis); 
                LocalShow(VisData);
            
                
            case 'speed'
                Vis = get(gca, 'UserData');
                Vis.speed = get(Data.speed(2),'Value');
                Vis.speed = 2^(Vis.speed-1);
                set(gca, 'UserData', Vis);
                if Vis.play == 1 && Vis.step ==  1
                    ['visual ' 'fw_play'];
                end % if
                if Vis.play == 1 && Vis.step == -1
                    ['visual ' 'bw_play'];
                end % if
                
        end % switch
        
    case 2
        % Initialize
        Action = varargin{1};
        if ~isstr(Action)
            error('Invalid Action for linadv');
        end % if
        
        switch Action
            case 'Initialize'
                VisData = varargin{2};
                LocalInitFig(VisData);
                LocalShow(VisData); 
                
        end % switch Action
end % switch nargin
% -------------------------------------------------------------------------

% function LocalShow  %
function LocalShow(VisData) %
% ************************************************
% Do the visualisation
% ************************************************
    global slider_Hnd
    
    Data   = get(gcf, 'UserData');

    if VisData.plotqr==1
        ax1=Data.axHndl;
        ax2=Data.axHndl2;
    else
        ax1=Data.axHndl;
    end
    
    Vis    = get(ax1, 'UserData');
    
    % Protection from reentering the visualization loop
    % -------------------------------------------------
    
    if Vis.draw == 1
        return;
    end % if
    Vis.draw = 1;
    
    % Get the data for visualization
    % ------------------------------    

    time   = Data.Vis.t;
    x      = Data.Vis.x;
    z      = Data.Vis.z;
    topo   = Data.Vis.topo;
    theta  = Data.Vis.theta;      
    tend   = time(length(time)); % Last element of time() contains
                                 % total time

    % Plot options                           
    v0      = Data.Vis.u00;
    tci     = Data.Vis.tci;
    vci     = Data.Vis.vci;
    tlim    = Data.Vis.tlim;
    vlim    = Data.Vis.vlim;
    qvlim   = VisData.qvlim;  
    qvci    = VisData.qvci;
    qclim   = VisData.qclim;
    qcci    = VisData.qcci;  
    qrlim   = VisData.qrlim;
    qrci    = VisData.qrci; 
    lhlim   = VisData.lhlim;
    lhci    = VisData.lhci;
    nclim   = VisData.nclim;
    ncci    = VisData.ncci;
    nrlim   = VisData.nrlim;
    nrci    = VisData.nrci;   
     
    % read in variables
    if VisData.plotu==1  
            u = Data.Vis.u;  
    end
    if VisData.plotqv==1
            qv = Data.Vis.qv;
    end
    if VisData.plotqc==1
            qc = Data.Vis.qc;
    end
    if VisData.plotnc==1
            nc = Data.Vis.nc;
    end
    if VisData.plotnr==1
            nr = Data.Vis.nr;
    end
    if VisData.plotlh==1
            lh = Data.Vis.lheat;
    end
    if VisData.plotqr==1
            qr = Data.Vis.qr;
            totprec = Data.Vis.totprec;
    end

    % Visualization loop
    while Vis.draw == 1
        switch Vis.step
            case 1
                Vis.n = Vis.n+1;
                if Vis.n > length(time)
                    Vis.n=Vis.n-length(time);
                end % if
                set(slider_Hnd, 'Value', Vis.n);   %: option for slider

            case -1
                Vis.n = Vis.n-1;
                if Vis.n < 1
                    Vis.n = length(time)+Vis.n;
                end % if
                set(slider_Hnd, 'Value', Vis.n);   %: option for slider
        end % switch
        set(ax1, 'UserData', Vis);

        % Draw the contour plot
        hold on;
    
        if VisData.plotqr==1
            cla;
            set(gcf, 'CurrentAxes', ax2);
            cla
            set(gcf, 'CurrentAxes', ax1);
        else
            cla;
        end


        % isentropes
        [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', theta(:,:)', ...
                tlim(1):tci:tlim(2),'LineColor',[0.5 0.5 0.5]);

        if VisData.plotu == 1  %
            % U: velocity

            % green contours
            [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', u(:,:,Vis.n)', ...
                vlim(1):vci:(v0-vci), 'g');
            set(h, 'LineWidth', 2)

            % red contours
            [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', u(:,:,Vis.n)', ...
                (v0+vci):vci:vlim(2), 'r');
            set(h, 'LineWidth', 2)
        end

        if VisData.plotqv == 1 
            % QV: water vapor mixing ratio

            [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', qv(:,:,Vis.n)', qvlim(1) : qvci : qvlim(2), 'LineColor',[186 212 244]/256.);
            set(h, 'LineWidth', 2) %
           
        end

        if VisData.plotqc == 1
            % QC: cloud water mixing ratio
            
            [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', qc(:,:,Vis.n)', qclim(1) : qcci: qclim(2), 'LineColor',[0 191 191]/256.);
            set(h, 'LineWidth', 2);

        end
        
        if VisData.plotnc == 1
            % NC: cloud droplet number density
            
            [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', nc(:,:,Vis.n)', nclim(1) : ncci: nclim(2), 'LineColor',[255 200 0]/256.);
            set(h, 'LineWidth', 2);

        end
        
        if VisData.plotnr == 1
            % NR: rain droplet number density
            
            [c,h] = contour(ax1,x(:,:)', z(:,:,Vis.n)', nr(:,:,Vis.n)', nrlim(1) : nrci: nrlim(2), 'LineColor', [255 69 0]/256.);
            set(h, 'LineWidth', 2);

        end
        
        if VisData.plotlh == 1
            % LHEAT: latent heating
            
            [c2,h2] = contour(ax1,x(:,:)', z(:,:,Vis.n)', lh(:,:,Vis.n)'.*3600., lhlim(1):lhci:-lhci, 'b');
            [c3,h3] = contour(ax1,x(:,:)', z(:,:,Vis.n)', lh(:,:,Vis.n)'.*3600., lhci:lhci:lhlim(2), 'y' );
            set(h2, 'LineWidth', 2);
            set(h3, 'LineWidth', 2);

        end

        if VisData.plotqr == 1
            % QR: rain water mixing ratio, total precipitation

            [c,h] = contour(ax1, x(:,:)', z(:,:,Vis.n)', qr(:,:,Vis.n)', qrlim(1): qrci : qrlim(2), 'LineColor',[0 230 150]/256.);
            set(h, 'LineWidth', 2);
            ylabel(ax1, 'z [km]');

            % plot total precipitation
            plot(ax2, x(:,1), totprec(:,Vis.n), 'Color',[0 230 150]/256.,'LineWidth', 2);
            
            set(gcf, 'CurrentAxes', ax1);
            
        end
        
        % Draw topography
        plot(x(:,1), topo(:,Vis.n), 'k', 'LineWidth', 2)
        
        hold off;
          
        %%drawnow;   
        if Vis.play == 1 % Pause only in 'loop' mode
            pause on;
            pause(Vis.delay/Vis.speed);    
        else
            pause off;
        end % if
        
        if ~ishandle(ax1)
            return;
        end % if
        
        Vis = get(ax1, 'UserData');
        if length(Vis) == 0
            return;
        end % if
        
        if Vis.play ~=1
            Vis.draw = 0;
        end % if
        
        % Time bar and Time info  
        % ----------------------
        if Vis.play == 0
	    set(Data.tInfo(1),'String',['Time: '...
		num2str(time(Vis.n)/3600),'h (',num2str(time(Vis.n)/Data.Vis.dt),')']);
            set(Data.tInfo(1),'Visible','on');
        else
            set(Data.tInfo(1),'String',['Time: '...
		num2str(time(Vis.n)/3600),'h (',num2str(time(Vis.n)/Data.Vis.dt),')']); %: show the time while in animation mode
            set(Data.tInfo(1),'Visible','on'); %: set(Data.tInfo(1),'Visible','off');
        end % if
    end % end 
    
    set(ax1, 'UserData', Vis);
% -------------------------------------------------------------------------


% ************************************************
% Initialize the visualization window
% ************************************************
function LocalInitFig(VisData)

    global slider_Hnd slider_text FigVisual

    % General Info
    % ------------    
    Black       = [0 0 0]/255;
    White       = [255 255 255]/255;
    UIBackColor = get(0,'DefaultUIControlBackgroundColor');
    FigColor    = UIBackColor;
    
    Info.Units            = 'points';
    Info.Visible          = 'on';
    Info.Interruptible    = 'on';
    Info.BusyAction       = 'queue';
    Info.HandleVisibility = 'callback';
    
    UIInfo                      = Info;
    UIInfo.BackGroundColor      = UIBackColor;
    UIInfo.ForeGroundColor      = Black;
    UIInfo.Units                = 'normalized';
    
   
    
    % Set Positions
    % -------------
    
    % Create visualization figure
    % ---------------------------
    FigVisual = figure( ...
        'Units', 'normalized', ...
        'MenuBar','none',...
        'Position', [0.1 0.1 0.8 0.8], ...  % [0.1 0.1 0.5 0.5] 
        'Name', [VisData.title,' - Visualization'], ...
        'Backingstore', 'off', ...
        'Tag', 'VisualFig', ...
        'NumberTitle', 'off', ...
        'Visible', 'off');

%     set(FigVisual,'SelectionType', 'alt');
%     get(FigVisual, 'SelectionType')

    
    % Create axes
    % -----------
    Info.Parent   = FigVisual;
    UIInfo.Parent = FigVisual;
    
    % Initialize default drawing mode, Data for axes
    Vis.n     = 1;
    Vis.play  = 0;
    Vis.step  = 0;
    Vis.speed = 1;
    Vis.delay = 0.1; % 1 second
    Vis.draw  = 0;
    Vis.show  = 0;
    
    if (VisData.plotqr == 0) 
        axHndl = axes( ...
            'Units', 'normalized', ...
            'Position', [0.07 0.17 0.88 0.76], ...
            'UserData', Vis, ...
            'xLim',VisData.xlim, ...
            'yLim',VisData.zlim, ...
            'Visible', 'off');

        if verLessThan('matlab','8.4.0')
            set(axHndl, 'DrawMode', 'fast')
        else
            set(axHndl, 'SortMethod', 'childorder')
        end
        
    else
        axHndl = axes( ...
            'Units', 'normalized', ...
            'Position', [0.07 0.47 0.88 0.5], ...
            'UserData', Vis, ...
            'xLim',VisData.xlim, ...
            'yLim',VisData.zlim, ...
            'Visible', 'off');
        
        axHndl2 = axes( ...
            'Units', 'normalized', ...
            'Position', [0.07 0.17 0.88 0.24], ...
            'UserData', Vis, ...
            'xLim',VisData.xlim, ...
            'yLim',VisData.totpreclim, ...
            'Visible', 'off');
        set(axHndl,'NextPlot','add') 
        
        if verLessThan('matlab','8.4.0')
            set(axHndl, 'DrawMode', 'fast')
            set(axHnd2, 'DrawMode', 'fast')
        else
            set(axHndl, 'SortMethod', 'childorder')
            set(axHnd2, 'SortMethod', 'childorder')
        end
    end
    

    
    
       
    % Arrange the buttons
    % -------------------
    ypos    = 0.02;  % 0.02
    btnlen  = 0.08;  % 0.08
    btnwid  = 0.08;  % 0.08
    spacing = 0.02;  % 0.02    
    
    % Time slider  %
    % ------------
    cbString = ['visual ' 'slider']; 
    min_step = 1; 
    max_step = length(VisData.t);
    step = 1 / (max_step - min_step);
    slider_Hnd = uicontrol(UIInfo, ...
        'Style', 'slider', ...
        'Position', [0.07 0.02 0.61-0.07 0.03], ...  
        'Min', min_step, 'Max', max_step, 'Value',1, ...
        'SliderStep', [step step], ...
        'Callback', cbString, ...
        'ButtonDownFcn', ['visual ' 'update_slider_text']); 
    
    % Text box for slider string  
    slider_text = uicontrol(UIInfo, ...
        'Style', 'text', ...
        'Units', 'normalized', ...
        'Position', [0.01 0.02 btnlen-0.02 0.04], 'Visible','off');  % 0.31 0.02 btnlen-0.02 0.04
    
    
    % 'Goto First Frame' button 
    % --------------------------------------
    labelStr = 'First';
    cbString = ['visual ' 'goto_first']; %
    goto_first_Hnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Position', [0.07 0.06 btnlen-0.02 0.04], ...  % [xpos ypos btnlen btnwid] 
        'String', labelStr, ...
        'ForegroundColor', 'k', ... %
        'FontWeight', 'bold', ... %
        'FontSize', 11, ... %
        'Callback', cbString);
    
    % The Backward Play button
    % ------------------------    
    btnNumber = 1;
    xpos = 0.07 + (btnNumber-1)*(btnlen+spacing);
    labelStr = '<<';
%     cbString = ['visual ' 'bw_step']; %
    cbString = ['visual ' 'bw_play']; %
    bwpHnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Position', [0.15 0.06 btnlen-0.02 0.04], ...  % [xpos ypos btnlen btnwid] 
        'String', labelStr, ...
        'ForegroundColor', 'g', ... %
        'FontWeight', 'bold', ... %
        'FontSize', 14, ... %
        'Callback', cbString);
    
    % The Backward Step button
    % ------------------------    
    btnNumber = 2;
    xpos = 0.05 + (btnNumber-1)*(btnlen+spacing);
    labelStr = '<';
%     cbString = ['visual ' 'bw_step']; %
    cbString = ['visual ' 'bw_step']; %
    bwsHnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Units', 'normalized', ...
        'Position', [0.23 0.06 btnlen-0.02 0.04], ... %
        'FontSize', 14, ... %
        'String', labelStr, ...
        'FontWeight', 'bold', ... %
        'Callback', cbString);
    
    % The Stop button
    % ---------------    
    btnNumber = 3;
    xpos = 0.05 + (btnNumber-1)*(btnlen+spacing);
    labelStr = '||';  % labelStr = 'Stop'; 
%     cbString = ['visual ' 'stop'];  %
    cbString = ['visual ' 'stop']; %
    stopHnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Units', 'normalized', ...
        'Position', [0.31 0.06 btnlen-0.02 0.04], ... %
        'String', labelStr, ...
        'ForegroundColor', 'r', ... %
        'FontWeight', 'bold', ... %
        'FontSize', 10, ... %
        'Callback', cbString);
    
    
    % The Forward Step button
    % -----------------------    
    btnNumber = 4;
    xpos = 0.05 + (btnNumber-1)*(btnlen+spacing);
    labelStr = '>';
%     cbString = ['visual ' 'fw_step']; %
    cbString = ['visual ' 'fw_step']; %
    fwsHnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Position', [0.39 0.06 btnlen-0.02 0.04], ... %
        'String', labelStr, ...
        'FontSize', 14, ... %
        'FontWeight', 'bold', ... %
        'Callback', cbString);
    
    
    % The Forward Play button
    % -----------------------    
    btnNumber = 5;
    xpos = 0.05 + (btnNumber-1)*(btnlen+spacing);
    labelStr = '>>';
%     cbString = ['visual ' 'fw_play'];  %
    cbString = ['visual ' 'fw_play']; %
    fwpHnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Units', 'normalized', ...
        'Position', [0.47 0.06 btnlen-0.02 0.04], ... %
        'String', labelStr, ...
        'ForegroundColor', 'g', ... %
        'FontWeight', 'bold', ... %
        'FontSize', 14, ... %
        'Callback', cbString);
    
        
    % 'Goto Last Frame' button   
    % --------------------------------------
    labelStr = 'Last';
    cbString = ['visual ' 'goto_last']; %
    goto_last_Hnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Position', [0.55 0.06 btnlen-0.02 0.04], ...  % [xpos ypos btnlen btnwid] 
        'String', labelStr, ...
        'ForegroundColor', 'k', ... %
        'FontWeight', 'bold', ... %
        'FontSize', 11, ... %
        'Callback', cbString);    
        
    
    % The Close button
    % ----------------    
    xpos = 1-btnlen-spacing;
    labelStr = 'Close';
%     cbString = ['visual ' 'close']; %
    cbString = ['visual ' 'close']; %
    closeHnd = uicontrol(UIInfo, ...
        'Style', 'pushbutton', ...
        'Units', 'normalized', ...
        'Position', [xpos ypos btnlen btnwid], ...
        'String', labelStr, ...
        'Callback', cbString);

    edtlen = btnlen;
    edtwid = btnwid*0.4;
    txtlen = 2*btnlen;
    txtwid = btnwid*0.4;
    xpos01 = 0.05 + btnNumber * (btnlen+spacing);
    xpos02 = xpos01 + txtlen + spacing;
    xpos03 = xpos02 + edtlen + spacing*0.25;
   
    % Option for choosing other speed
    % -------------------------------
    
    labelStr = 'Speed';
    speedhintHnd = uicontrol(UIInfo, ...
        'Style', 'text', ...
        'Units', 'normalized', ...
        'Position', [xpos01 + 0.08 ypos 0.08 txtwid], ... % [xpos01 ypos txtlen txtwid]  
        'String', labelStr);

    labelStr = '1x|2x|4x|8x|16x';
%     cbString = ['visual ' 'speed']; %
    cbString = ['visual ' 'speed']; %
    speedchoiceHnd = uicontrol(UIInfo, ...
        'Style', 'popup', ...
        'Units', 'normalized', ...
        'Position', [xpos02 ypos edtlen edtwid], ...
        'String', labelStr, ...
        'Callback',cbString);
    
    % Information about time
    % ----------------------     
    timeInfo = uicontrol(UIInfo, ...
        'Style', 'text', ...
        'HorizontalAlignment','left', ...
        'BackgroundColor', [.941 .941 .941], ... %: default BG color was white
	'Position', [xpos01+0.08  0.06 xpos02-xpos01 txtwid], ...  % 0.7 0.91 3*btnlen txtwid   0.85
        'Visible','off');
           
    
    Data.axHndl  = axHndl;
    if (VisData.plotqr==1)
        Data.axHndl2 = axHndl2;
    end
    Data.Vis     = VisData;
    Data.move    = [bwpHnd, bwsHnd, stopHnd, fwsHnd, fwpHnd];
    Data.close   = closeHnd;
    Data.speed   = [speedhintHnd, speedchoiceHnd];
    Data.tInfo   = timeInfo;

    set(FigVisual, 'Visible', 'on', 'UserData', Data);
    set(axHndl, 'Visible', 'on');
    xlabel(axHndl,'x [km]');
    ylabel(axHndl,'z [km]');
    if (VisData.plotqr==1)
            set(axHndl2, 'Visible', 'on');
            xlabel(axHndl2,'x [km]')
            ylabel(axHndl2,'[mm]')
    end