function [unew,unow,snew,snow,qvnew,qvnow,qcnew,qcnow,qrnew,qrnow,ncnew,ncnow,nrnew,nrnow] = ...
         horizontal_diffusion(tau,unow,unew,snow,snew,qvnow,qvnew,qcnow,qcnew,qrnow,qrnew,ncnow,ncnew,nrnow,nrnew)

% global variables
% -----------------------
global idbg nb nx nx1 nxb1 imoist_diff irelax


% apply 2nd order horizontal diffusion
% -----------------------
    ind = (tau>0);
    
    if (idbg==1 && ~isempty(ind))
       fprintf('Apply diffusion and gravity wave absorber ...\n');
    end %if
    
    taumat = tau(ones(nxb1, 1), :);
    
    if all(tau <= 0) 
        return
    elseif any(tau <= 0)
        sel = (taumat > 0);
        
        i=nb+(1:nx1);
        unew(i,:) = (unow(i,:) + taumat(i,:).*(unow(i-1,:)-2*unow(i,:)+unow(i+1,:))/4.).*sel(i,:) + unow(i,:).*~sel(i,:);
        
        i=nb+(1:nx);
        snew(i,:) = (snow(i,:) + taumat(i,:).*(snow(i-1,:)-2*snow(i,:)+snow(i+1,:))/4.).*sel(i,:) + snow(i,:).*~sel(i,:);
        
        if (nargin>5 && imoist_diff ==1)
            qvnew(i,:) = (qvnow(i,:) + taumat(i,:).*(qvnow(i-1,:)-2*qvnow(i,:)+qvnow(i+1,:))/4.) .*sel(i,:) + qvnow(i,:).*~sel(i,:);
            qcnew(i,:) = (qcnow(i,:) + taumat(i,:).*(qcnow(i-1,:)-2*qcnow(i,:)+qcnow(i+1,:))/4.) .*sel(i,:) + qcnow(i,:).*~sel(i,:);
            qrnew(i,:) = (qrnow(i,:) + taumat(i,:).*(qrnow(i-1,:)-2*qrnow(i,:)+qrnow(i+1,:))/4.) .*sel(i,:) + qrnow(i,:).*~sel(i,:);
        end % if
        
        if (nargin>11 && imoist_diff ==1)
            nrnew(i,:) = (nrnow(i,:) + taumat(i,:).*(nrnow(i-1,:)-2*nrnow(i,:)+nrnow(i+1,:))/4.) .*sel(i,:) + nrnow(i,:).*~sel(i,:);
            ncnew(i,:) = (ncnow(i,:) + taumat(i,:).*(ncnow(i-1,:)-2*ncnow(i,:)+ncnow(i+1,:))/4.) .*sel(i,:) + ncnow(i,:).*~sel(i,:);
        end %if
    else
        i=nb+(1:nx1);
        unew(i,:) = (unow(i,:) + taumat(i,:).*(unow(i-1,:)-2*unow(i,:)+unow(i+1,:))/4.);
        
        i=nb+(1:nx);
        snew(i,:) = (snow(i,:) + taumat(i,:).*(snow(i-1,:)-2*snow(i,:)+snow(i+1,:))/4.);
        
        if (nargin>5 && imoist_diff ==1)
            qvnew(i,:) = (qvnow(i,:) + taumat(i,:).*(qvnow(i-1,:)-2*qvnow(i,:)+qvnow(i+1,:))/4.);
            qcnew(i,:) = (qcnow(i,:) + taumat(i,:).*(qcnow(i-1,:)-2*qcnow(i,:)+qcnow(i+1,:))/4.);
            qrnew(i,:) = (qrnow(i,:) + taumat(i,:).*(qrnow(i-1,:)-2*qrnow(i,:)+qrnow(i+1,:))/4.);
        end % if
        
        if (nargin>11 && imoist_diff ==1)
            nrnew(i,:) = (nrnow(i,:) + taumat(i,:).*(nrnow(i-1,:)-2*nrnow(i,:)+nrnow(i+1,:))/4.);
            ncnew(i,:) = (ncnow(i,:) + taumat(i,:).*(ncnow(i-1,:)-2*ncnow(i,:)+ncnow(i+1,:))/4.);
        end %if
    end %if 
    
     % exchange periodic boundaries
    if (irelax==0) 
        [unew] = periodic(unew,nx1,nb);
        [snew] = periodic(snew,nx,nb);

        if (nargin>5 && imoist_diff ==1)
            [qvnew] = periodic(qvnew,nx,nb);
            [qcnew] = periodic(qcnew,nx,nb);
            [qrnew] = periodic(qrnew,nx,nb);
        end %if
        
        if (nargin>11 && imoist_diff ==1)
            [ncnew] = periodic(ncnew,nx,nb);
            [nrnew] = periodic(nrnew,nx,nb);
        end %if
    end %if
    
    % update
    unow = unew;  
    snow = snew;
    
    if (nargin>5 && imoist_diff ==1)
        qvnow = qvnew;
        qcnow = qcnew;
        qrnow = qrnew;
    end %if
    
    if (nargin>11 && imoist_diff ==1)
        ncnow = ncnew;
        nrnow = nrnew;
    end %if
    