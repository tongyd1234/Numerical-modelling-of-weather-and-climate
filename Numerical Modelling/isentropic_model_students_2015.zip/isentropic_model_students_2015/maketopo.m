function [topo]=maketopo(topo,nxb)

global irelax idbg dx nx nb topomx topowd

% Topography definition
% ----------------------
if (idbg==1)
  display('   Topography ...');
end %if

x0 = (nxb-1)/2 + 1 ;

toponf = topo;
i=1:nxb;
x(i,1) = (i-x0).*dx;
toponf(i,1) = topomx.*exp(-(x(i,1)./topowd).^2);


i=2:nxb-1; % filter
topo(i) = toponf(i) + 0.25.*(toponf(i-1)-2.*toponf(i)+toponf(i+1));

