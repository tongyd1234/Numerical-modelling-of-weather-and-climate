function [unew] = prog_velocity(uold,unow,mtg,dthetadt)

% global variables
% ------------------------
global nz nb nx idbg dx dt dtdx idthdt dth

    if (idbg==1)
       fprintf('Prognostic step: Velocity ...\n');
    end %if
    
    % declare unew
    unew = zeros(nx+1+2*nb,nz);

    % *** Exercise 2.1 velocity ***
    % *** time step for momentum ***
    % *** edit here ***
    i=nb+(1:nx+1);
    k=1:nz;
    unew(i,k)=uold(i,k)-2*dtdx*((mtg(i,k)-mtg(i-1,k))+0.5*unow(i,k).*(unow(i+1,k)-unow(i-1,k)));
    if (idthdt==1 & nargin > 3)
    unew(i,k) = unew(i,k)- 0.25*dt./dth.*(dthetadt(i-1,k+1)+dthetadt(i,k+1)+dthetadt(i-1,k)+dthetadt(i,k))...
        *(unow(i,k+1)-unow(i,k-1));
    end
    % *** Exercise 2.1 velocity ***
